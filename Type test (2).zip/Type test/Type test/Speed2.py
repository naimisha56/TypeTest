from time import time  
from tkinter import *
from difflib import SequenceMatcher
from tkinter import messagebox
import random
import math


def mainst():
    global St
    global L
    global op
    global text
    op=Tk()
    op.geometry("700x400")
    op.title("Test")
    text=StringVar()
    P=PhotoImage(file="Type test/nature1.png")
    L2=Label(op,image=P)
    L2.pack(fill=BOTH, expand=YES)
    M1=Label(op,text="Typing Speed Test",font = "Helvetica 25 bold italic").place(x=200,y=10) 
    L=Label(op,text='Do You Wanna Know Your Typing Speed?')
    L.place(x=180,y=150)
    L.config(font=("Courier", 13))
    St=Button(op,text="ClickHere",width=8,height=2,command=lambda:start())
    St.place(x=300,y=200)
    op.resizable(0,0)
    op.mainloop()
def get_sen():
    f=open("Type test/sentences.txt").read()
    sens=f.split('\n')
    sen=random.choice(sens)
    return sen

def start():
    St.destroy()
    L.destroy()
    global stime
    global S 
    global e1
    global L2
    global sentence
    sentence=get_sen()
    L2=Label(op,text=sentence)
    L2.place(x=120,y=150)
    L2.config(font=('Calibari',13))
    e1=Entry(op,textvariable=text,width=80,bd=10,relief=RIDGE)
    e1.place(x=100,y=200)
    e1.bind('<Control-x>', lambda e: 'break') #disable cut
    e1.bind('<Control-c>', lambda e: 'break') #disable cut
    e1.bind('<Control-v>', lambda e: 'break') #disable paste
    e1.bind('<Button-3>', lambda e: 'break')  #disable right-click
    stime = time()
    S=Button(op,text="Submit",width=8,height=2,command=lambda:results())
    S.place(x=300,y=250)
    op.bind('<Return>',results)

    
def results(event=None):
    global R
    global M2
    txt=e1.get()
    if(len(txt)==0):
        messagebox.showerror("Error","You Shouldn't Leave a Empty Message")
    else:
        S.destroy()
        etime=time()
        accuracy=(SequenceMatcher(None,sentence,txt).ratio())*100      
        words=txt.split()
        tt=etime-stime
        speed=len(words)/tt        
        M2=Label(op)
        M2.place(x=400,y=250)
        M2.config(text="RESULTS:\nAccuracy={0}\nTypingspeed={1}words/secs".format(round(accuracy),speed))        
        R=Button(op,text="Reset",width=8,height=2,command=lambda:Reset())
        R.place(x=300,y=250)
        op.bind("<Return>",Reset)

def Reset(event=None):
    R.destroy()
    e1.delete(0,END)
    e1.destroy()
    M2.destroy()
    L2.destroy()
    start()
        
mainst()
